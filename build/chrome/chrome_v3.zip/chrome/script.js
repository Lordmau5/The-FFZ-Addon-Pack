var ce = document.createElement.bind(document);
var s = ce('script');
s.type = 'text/javascript';
s.src = 'https://cdn.lordmau5.com/ffz-ap/ffz-ap.min.js';
document.head.appendChild(s);
